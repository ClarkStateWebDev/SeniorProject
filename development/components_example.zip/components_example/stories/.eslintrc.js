module.exports = {
  rules: {
    'import/no-extraneous-dependencies': 0,
    'no-alert': 'off'
  },
}
