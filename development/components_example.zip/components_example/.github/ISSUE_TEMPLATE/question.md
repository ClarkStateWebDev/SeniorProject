---
name: 💬 Questions / Help
about: If you have questions, please check our Slack workspace
---

## 💬 Questions and Help

### Please note that this issue tracker is not a help forum and this issue may be closed.

Before you submit an issue we recommend you drop into our [Slack workspace](https://hospitalrun-slack.herokuapp.com/) and ask any questions you have or mention any problems you've had getting started with HospitalRun.
