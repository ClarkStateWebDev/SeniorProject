export const invalidSpinner = 'Invalid spinner'
