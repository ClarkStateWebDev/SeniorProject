export type ButtonsAlignment = 'left' | 'right' | 'center' | 'edges'
