declare module 'video-react'
